#!/usr/bin/env python3

#Copyright 2020, Tobey Thorn
#All rights reserved.

#Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
#1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
#2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
#3. Neither the name “Protowrite” nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

#THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#--- to do ---
# encapsulate main function
#nav and masthead don't feel right. Figure out how this system should work.

import converter
import re
import sys
import os
from os import walk
from html.parser import HTMLParser

void_html_tags = ['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'menuitem', 'meta', 'param', 'source', 'track', 'wbr']

base_url = '/'
if len(sys.argv) > 1:
	base_url = sys.argv[1]
	
if not (base_url.startswith('/') or base_url.startswith('http://') or base_url.startswith('https://') or base_url.startswith('file://')  or base_url.startswith('localhost')):
	base_url = '/' + base_url
if not base_url.endswith('/'):
	base_url = base_url + '/'
	
print('...............Prepress building site for', base_url)


class URL_Parser(HTMLParser):
	def __init__(self):
		HTMLParser.__init__(self)
		self.output = ''
		self.base_url = '/'

	def handle_starttag(self, tag, attrs):
		self.output = self.output + '<' + tag
		for attr in attrs:
			a, b = attr
			if b == None:
				self.output = self.output + ' ' + a
			else:
				if a == 'href' or a == 'src' or a == 'data':
					b = re.sub('^//', self.base_url, b)
				self.output = self.output + ' ' + a + '="' + b + '"'
		if tag in void_html_tags:
			self.output = self.output + '/>'
		else:
			self.output = self.output + '>'

	def handle_endtag(self, tag):
		if tag in void_html_tags:
			pass
		else:
			self.output = self.output + '</' + tag + '>'

	def handle_data(self, data):
		self.output = self.output + escape_text(data)

	def handle_decl(self, data):
		self.output = self.output + '<!' + data + '>'
		
	def handle_comment(self, data):
		self.output = self.output + '<!--' + data + '-->'
		
	def process_urls(self, html, base_url):
		self.base_url = '/'
		#rather, should return error and abort action? is this necessary?
		self.base_url = base_url
		self.output = ''
		self.feed(html)
		return self.output


def escape_address(address):
	if address.startswith('data:') or address.startswith('javascript:'):
		return ''
	else:
		address = address.replace('&', '&amp;')
		address = address.replace('<', '&lt;')
		address = address.replace('>', '&gt;')
		address = address.replace('\"', '')
		address = address.replace('\'', '')
		return address
		
def escape_text(text):
	text = text.replace('&', '&amp;')
	text = text.replace('<', '&lt;')
	text = text.replace('>', '&gt;')
	return text

def parse_front_matter(input):
	front = ''
	back = input
	fm = re.search('^(\-\-\-\n)([\s\S]*?)(\n\-\-\-)($|\n)([\s\S]{0,})', input) #can I improve, simplify, or speed up this regex???
	if fm:
		front = fm.group(2)
		back = fm.group(5)
		
	front_matter = {}
	front_matter['layout'] = 'basic.html'
	front_matter['style'] = '//static/css/basic.css'
	lines = re.split('\n', front)
	for line in lines:
		set = line.partition('\t')
		#check that key is \w+ with no spaces. however, this is actually not necessary in python
		if not set[1] == '':
			a = set[0].strip()
			c = set[2].strip()
			front_matter[a] = escape_address(c)
		else:
			pass
	front_matter['style'] = '<link rel="stylesheet" type="text/css" href="' + escape_address(front_matter['style']) + '" />'
	front_matter['content'] = back
	return front_matter


def get_components():
	components = {}
	_, _, filenames = next(walk('components'))
	for filename in filenames:
		if not filename.startswith('.'):
			if filename.endswith('.pre') or filename.endswith('.html'):
				try:
					f = open(os.path.normpath('components/' + filename))
					input = f.read()
					output = input
					if filename.endswith('.pre'):
						output = converter.to_html(input)
						filename = re.sub('.pre$', '.html', filename)
					components[filename] = output
				except:
					pass
	return components
	
def get_layouts():
	layouts = {}
	_, _, filenames = next(walk('layouts'))
	for filename in filenames:
		if not filename.startswith('.'):
			if filename.endswith('.html'):
				try:
					f = open(os.path.normpath('layouts/' + filename))
					input = f.read()
					output = input
					name = filename
					layouts[name] = output
				except:
					pass
	return layouts
	
components = get_components()
layouts = get_layouts()

num_pages_built = 0
num_errors = 0

_, _, filenames = next(walk('pages'))
for filename in filenames:
	if not filename.startswith('.'):
		if filename.endswith('.pre') or filename.endswith('.html'):
			try:
				f = open(os.path.normpath('pages/' + filename))
				input = f.read()
				page = parse_front_matter(input)
				if filename.endswith('.pre'):
					page['content'] = converter.to_html(page['content'])
					filename = re.sub('.pre$', '.html', filename)
				
				if not 'title' in page:
					page['title'] = filename
				
				output = ''
				if page['layout'] in layouts:
					layout = layouts[page['layout']]
					parts = re.split('({{.*?}})' , layout)
					for part in parts:
						m = re.search('^{{(.*?)}}$', part)
						if m:
							a = m.group(1).strip()
							if a in components:
								part = components[a]
							elif a in page:
								part = page[a]
						output = output + part			
				else:
					output = article['content']
				
				u_parser = URL_Parser()
				output = u_parser.process_urls(output, base_url)
			
				f = open(os.path.normpath('site/' + filename), 'w')
				f.write(output)
				print(filename, '...built')
				num_pages_built = num_pages_built + 1
			except:
				print(filename, '...failed')
				num_errors = num_errors + 1

print(num_pages_built, 'pages built') 
print(num_errors, 'pages failed')

