#!/usr/bin/env python3

#Copyright 2020, Tobey Thorn
#All rights reserved.

#Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
#1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
#2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
#3. Neither the name “Protowrite” nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

#THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# ----- to do ------
# decide if future spec should allow for citation links in lists
# Make output a parentless list, not a dictionary?


import re

image_extensions = ['.jpg', '.jpeg', '.png', '.apng', '.webp', '.gif', '.avif']
audio_extensions = ['.mp3', '.ogg', '.oga', '.flac', '.mka']
video_extensions = ['.mp4', '.mov', '.mkv', '.ogv', '.webp', '.gif', '.avif']

def is_code_block(lines):
	output = True
	for i in range(1, len(lines), 1):
		if not lines[i].startswith('\t'):
			output = False
			break
	return output
	
	
def paragraphize(text, citations):
	content = []
	bits = 	re.split('(\[.*?\])', text)
	for bit in bits:
		match_citation_link = re.search('^\[([0-9]{1,})\]$', bit)
		match_external_link = re.search('^\[(.*?)([ | |　])([/|http://|https://]\S+)\]$', bit)
		if match_citation_link and citations:
			piece = {'type': 'citation_link', 'content': [], 'address': match_citation_link.group(1)}
			piece_text = {'type': 'text', 'content': match_citation_link.group(0)}
			piece['content'].append(piece_text)
			content.append(piece)
		elif match_external_link:
			piece = {'type': 'external_link', 'content': [], 'address': match_external_link.group(3)}
			piece_text = {'type': 'text', 'content': match_external_link.group(1)}
			piece['content'].append(piece_text)
			content.append(piece)
		elif bit == '[L]':
			piece = {'type': 'text', 'content': '['}
			content.append(piece)
		elif bit == '[R]':
			piece = {'type': 'text', 'content': ']'}
			content.append(piece)
		elif bit == '[/]':
			piece = {'type': 'text', 'content': '/'}
			content.append(piece)
		elif bit == '[http:]':
			piece = {'type': 'text', 'content': 'http:'}
			content.append(piece)
		elif bit == '[https:]':
			piece = {'type': 'text', 'content': 'https:'}
			content.append(piece)
		elif bit != '':
			piece = {'type': 'text', 'content': bit}
			content.append(piece)
	return content


def jsonify(plain_text):
	plain_text = re.sub('\n+$', '', plain_text)

	if plain_text.startswith('\n'):
		plain_text = '\n' + plain_text
	else:
		plain_text = '\n\n' + plain_text

	plain_text = re.sub('[\n]{5,}', '\n\n\n\n\n', plain_text)

	ab_list = re.split('([\n]{2,})', plain_text)
	block_text_list = []

	for i in range(2, len(ab_list), 2):
		block_text_list.append( ab_list[i-1] + ab_list[i] )

	article = {'type': 'article', 'content': []}
	for block_text in block_text_list:
		# for some odd reason, re.split is much faster than string.split(), but only with [\n]{1, }
		lines = re.split('[\n]{1,}', block_text)
		if block_text.startswith('\n\n\n\n\n'):
			block = {'type': 'header', 'content': []}
			head = {'type': 'heading_1', 'content': []}
			heading_text = {'type': 'text', 'content': lines[1]}
			article['content'].append(block)
			block['content'].append(head)
			head['content'].append(heading_text)
			if len(lines) > 2:
				list = {'type': 'caption', 'content': []}
				block['content'].append(list)
				for i in range(2, len(lines), 1):
					item = {'type': 'paragraph', 'content': []}
					item_text = {'type': 'text', 'content': lines[i]}
					list['content'].append(item)
					item['content'].append(item_text)
		elif block_text.startswith('\n\n\n') or block_text.startswith('\n\n\n\n'):
			block = {'type': 'header', 'content': []}
			head = {'type': 'heading_2', 'content': []}
			heading_text = {'type': 'text', 'content': lines[1]}
			article['content'].append(block)
			block['content'].append(head)
			head['content'].append(heading_text)
			if len(lines) > 2:
				list = {'type': 'caption', 'content': []}
				block['content'].append(list)
				for i in range(2, len(lines), 1):
					item = {'type': 'paragraph', 'content': []}
					item_text = {'type': 'text', 'content': lines[i]}
					list['content'].append(item)
					item['content'].append(item_text)
		elif len(lines) == 2 and re.search('^\*[\s]{0,}\*[\s]{0,}\*$', lines[1]):
			block = {'type': 'section_break', 'content': ''}
			article['content'].append(block)
		elif re.search('^\/[\S]{0,}$', lines[1]) or re.search('^http:\/\/[\S]{0,}$', lines[1]) or re.search('^https:\/\/[\S]{0,}$', lines[1]):
			#could make this single regex
			block = {'type': 'figure', 'content': []}
			media_type = 'embed'
			address = lines[1]
			extension = ''
			m = re.search('(\.\w+)$', address)
			if m:
				extension = m.group(1)
			if extension in image_extensions:
				media_type = 'image'
			elif extension in audio_extensions:
				media_type = 'audio'
			elif extension in video_extensions:
				media_type = 'video'	
			media = {'type': media_type, 'content': lines[1], 'address': lines[1]}
			article['content'].append(block)
			block['content'].append(media)
			list = {'type': 'caption', 'content': []}
			block['content'].append(list)
			for i in range(2, len(lines), 1):
				item = {'type': 'paragraph', 'content': []}
				item_text = {'type': 'text', 'content': lines[i]}
				list['content'].append(item)
				item['content'].append(item_text)
		elif is_code_block(lines):
			block = {'type': 'figure', 'content': []}
			code = {'type': 'code', 'content': []}
			source = '\n';
			for i in range(1, len(lines), 1):
				l = re.sub( '^\t', '', lines[i]) + '\n'
				source = source + l
			code_text = {'type': 'text', 'content': source}
			article['content'].append(block)
			block['content'].append(code)
			code['content'].append(code_text)
		elif re.search('^[ | |　]', lines[1]) and (lines[1].partition('\t'))[1] == '':
			block = {'type': 'figure', 'content': []}
			block_quote = {'type': 'block_quote', 'content': []}
			block_quote_paragraph = {'type': 'paragraph', 'content': []}
			block_quote_text = {'type': 'text', 'content': re.sub( '^\t', '', lines[1]) }
			article['content'].append(block)
			block['content'].append(block_quote)
			block_quote['content'].append(block_quote_paragraph)
			block_quote_paragraph['content'].append(block_quote_text)
			list = {'type': 'caption', 'content': []}
			block['content'].append(list)
			for i in range(2, len(lines), 1):
				item = {'type': 'paragraph', 'content': []}
				item_text = {'type': 'text', 'content': lines[i]}
				list['content'].append(item)
				item['content'].append(item_text)
		elif (lines[1].partition('\t'))[1] != '' or len(lines) > 2:
			#rename bit to cell and bits to cells?
			block = {'type': 'list', 'content': []}
			for i in range(1, len(lines), 1):
				bits = re.split('\t', lines[i])
				item = {'type': 'item', 'content': []}
				m = re.search('^\[([0-9]{1,})\]$', bits[0])
				if m:
					item['id'] = m.group(1)
				for bit in bits:
					content = paragraphize(bit.strip(), False)		
					value = {'type': 'value', 'content': content}
					item['content'].append(value)
				block['content'].append(item)
			if len(block['content']) > 0:
				#this condition shouldn't be necessary?
				article['content'].append(block)
		else:
			content = paragraphize( re.sub('^\n\n', '', block_text), True )
			block = {'type': 'paragraph', 'content': content}
			if len(block['content']) > 0:
				article['content'].append(block)
	return article

#to make this more robust, check that type and content exist for all objects. that way, if bad json comes in, no problem.
def htmlify(object):
	def escape_address(address):
		if address.startswith('data:') or address.startswith('javascript:'):
			return ''
		else:
			address = address.replace('&', '&amp;')
			address = address.replace('<', '&lt;')
			address = address.replace('>', '&gt;')
			address = address.replace('\"', '')
			address = address.replace('\'', '')
			return address
			
	html = ''
	if object['type'] == 'text':
		text = object['content']
		text = text.replace('&', '&amp;')
		text = text.replace('<', '&lt;')
		text = text.replace('>', '&gt;')
		html = html + text
	elif object['type'] == 'image':
		html = html + '<img src="' +  escape_address(object['address']) + '" alt="' + escape_address(object['content']) + '"/>'
	elif object['type'] == 'audio':
		html = html + '<audio controls src="' +  escape_address(object['address']) + '">' + escape_address(object['content']) + '</audio>'
	elif object['type'] == 'video':
		html = html + '<video controls src="' +  escape_address(object['address']) + '">' + escape_address(object['content']) + '</video>'
	elif object['type'] == 'embed':
		html = html + '<div class="ratio"><object data="' +  escape_address(object['address']) + '">' + escape_address(object['content']) + '</object></div>'
	elif object['type'] == 'section_break':
		html = html + '<hr />'
	else:
		open = ''
		close = ''
		if object['type'] == 'article':
			open = ''
			close = ''
		if object['type'] == 'list':
			open = '<ol>'
			close = '</ol>'
		elif object['type'] == 'paragraph':
			open = '<p>'
			close = '</p>'
		elif object['type'] == 'heading_1':
			open = '<h1>'
			close = '</h1>'
		elif object['type'] == 'heading_2':
			open = '<h2>'
			close = '</h2>'
		elif object['type'] == 'header':
			open = '<header>'
			close = '</header>'
		elif object['type'] == 'item':
			if 'id' in object:
				open = '<li id="' + escape_address(object['id']) + '">'
			else:
				open = '<li>'
			close = '</li>'
		elif object['type'] == 'value':
			open = '<span>'
			close = '</span>'
		elif object['type'] == 'figure':
			open = '<figure>'
			close = '</figure>'
		elif object['type'] == 'caption':
			open = '<figcaption>'
			close = '</figcaption>'
		elif object['type'] == 'block_quote':
			open = '<blockquote>'
			close = '</blockquote>'
		elif object['type'] == 'citation_link':
			open = '<a href="' + '#' + escape_address(object['address']) + '">'
			close = '</a>'
		elif object['type'] == 'external_link':
			open = '<a>'
			if object['address'] != '':
				open = '<a href="' + escape_address(object['address']) + '">'
			close = '</a>'
		elif object['type'] == 'code':
			open = '<pre>'
			close = '</pre>'
		html = html + open
		for i in range(0, len(object['content']), 1):	
			html = html + htmlify(object['content'][i])
		html = html + close
	return html
	
	
def to_html(text):
	return htmlify(jsonify(text))
	
def to_json(text):
	return jsonify(text)
	